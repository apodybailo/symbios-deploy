from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route("/")
def home():
    return "KhataSvitu бот активний!"

@app.route("/photo", methods=["POST"])
def handle_photo():
    # Псевдо-логіка прийому фото
    return jsonify({"status": "Фото отримано, обробка запущена."})

@app.route("/note", methods=["POST"])
def handle_note():
    data = request.json
    return jsonify({"received_note": data.get("text", "Пусто")})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
