#!/bin/bash
python app.py & 
sleep 3
ngrok http 8000 --domain=symbios-photo.ngrok.app
