#!/bin/bash
python app.py & 
sleep 3
ngrok http 8000 --domain=symbios-programmer.ngrok.app
